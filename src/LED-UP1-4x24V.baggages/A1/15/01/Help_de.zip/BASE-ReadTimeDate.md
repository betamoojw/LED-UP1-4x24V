### Uhrzeit und Datum abfragen

Ermöglicht die Abfrage der Uhrzeit und des Datums nach einem Neustart des Geräts.