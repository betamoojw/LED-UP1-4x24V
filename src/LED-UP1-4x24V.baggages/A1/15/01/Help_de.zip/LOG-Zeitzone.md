﻿### Zeitzone

Für die korrekte Berechnung der Zeit wird die Zeitzone des Standortes benötigt.

