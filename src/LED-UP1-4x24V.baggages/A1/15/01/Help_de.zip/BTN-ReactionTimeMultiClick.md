### Reaktionszeiten: Mehrfach-Klick

Gibt die Wartezeit an, wie lange auf einen weiteren Tastendruck gewartet wird. Sobald die Zeit abgelaufen ist, wird der bis dahin gezählte Mehrfach-Klick ausgeführt.