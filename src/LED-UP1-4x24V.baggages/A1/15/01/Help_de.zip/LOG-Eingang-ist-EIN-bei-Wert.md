﻿### Eingang ist EIN bei Wert

Hier wird ein Wert der Werteliste angegeben.

