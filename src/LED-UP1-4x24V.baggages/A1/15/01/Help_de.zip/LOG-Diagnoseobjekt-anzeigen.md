﻿### Diagnoseobjekt anzeigen

Mit einem 'Ja' wird das KO 7 'Diagnoseobjekt' freigeschaltet.

