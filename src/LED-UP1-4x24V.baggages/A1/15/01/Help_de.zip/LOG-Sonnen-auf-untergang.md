﻿### Sonnen auf-/untergang

In dieser Spalte werden Stunden eingestellt als Versatz zum Sonnenauf- oder -untergang.

