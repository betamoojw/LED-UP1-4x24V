### Datentyp

Wähle einen Datentyp aus.