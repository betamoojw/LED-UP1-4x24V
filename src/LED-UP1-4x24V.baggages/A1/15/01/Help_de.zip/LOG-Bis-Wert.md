﻿### Bis-Wert

Hier wird der Bis-Wert (also die obere Grenze) eines Wertebereichs angegeben.


