﻿### Ausgang hat eine Treppenlichtfunktion

Wird hier ein "Ja" ausgewählt, erscheinen die Parameter für die Treppenlichtfunktion.

