### Sperre

Durch die Verwendung der Sperre kann der virtuelle Taster gesperrt werden.