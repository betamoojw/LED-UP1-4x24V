﻿### Längengrad

In dem Feld wird der Längengrad des Standortes eingegeben.

