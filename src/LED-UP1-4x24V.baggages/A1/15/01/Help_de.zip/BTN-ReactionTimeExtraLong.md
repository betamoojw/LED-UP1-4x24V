### Reaktionszeiten: Extra Langer Tastendruck

Gibt an, ab wann der gehaltene Tastendruck als "Extra langer Tastendruck" gewertet wird. Sobald die Zeit erreicht wurde, wird ein passendes "Press"-Event ausgelöst. Sobald nun losgelassen wird, wird das dazugehörige "Release"-Event ausgelöst.