﻿### Watchdog aktivieren

Mit einem 'Ja' wird der Watchdog eingeschaltet.

