### Geöffnet

Was für ein Status sollte bei einem geöffneten Stromkreis gesendet werden?