﻿### oder bei Wert

Hier wird ein weiterer Wert der Werteliste angegeben.

