### Zusatzausgang

Mit dem Zusatzausgang besteht die Möglichkeit, ein zusätzliches Telegramm zu senden. Dieses Telegramm ist auf das DPT1 beschränkt und wird beim Loslassen gesendet.