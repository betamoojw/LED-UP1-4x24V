### Aktiv

Schalte den Kanal ein, wenn der Binäreingang verwendet werden soll.