### Zyklisches senden

In welchen regelmäßigen Abständen sollte der aktuelle Status gesendet werden?