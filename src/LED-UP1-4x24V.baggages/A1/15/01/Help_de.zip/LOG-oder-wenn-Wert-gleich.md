﻿### oder wenn Wert gleich

Hier wird ein weiterer Wert zum Vergleich angegeben.

