### Startverzögerung

Die Startverzögerung ist darauf ausgelegt, zu verhindern, dass beim Neustart alle Geräte gleichzeitig den Bus überlasten. Normalerweise erfolgt während dieser Verzögerung keine Kommunikation über den Bus. Die genaue Funktionsweise hängt jedoch vom jeweiligen Modul in der Firmware ab.