### Uhrzeit und Datum empfangen

Die Uhrzeit und das Datum können entweder über zwei separate Kommunikationsobjekte (DPT10 und DPT11) oder über ein kombiniertes Kommunikationsobjekt (DPT19) empfangen werden.