### Reaktionszeiten: Langer Tastendruck

Gibt an, ab wann der gehaltene Tastendruck als "Langer Tastendruck" gewertet wird. Sobald die Zeit erreicht wurde, wird ein passendes "Press"-Event ausgelöst. Sollte nun vor dem Ablauf der Reaktionszeit für "Extra langer Tastendruck" (falls aktiviert) losgelassen werden, so wird das dazugehörige "Release"-Event ausgelöst.
