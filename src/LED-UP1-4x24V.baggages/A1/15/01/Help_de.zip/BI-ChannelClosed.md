### Geschlossen

Was für ein Status sollte bei einem geschlossenem Stromkreis gesendet werden?