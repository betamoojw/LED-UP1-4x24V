### Gerätestandort

Hier hast du die Möglichkeit, GPS-Koordinaten für den Standort deines Geräts präzise zu hinterlegen. Diese Informationen können von verschiedenen Modulen genutzt werden, um beispielsweise den Sonnenstand zu berechnen. Die Eingabe erfolgt in Dezimalschreibweise.

Tipp: Verwende Online-Karten oder GPS-Geräte, um genaue Koordinaten zu erhalten.